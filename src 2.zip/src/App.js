import React from 'react';
import Routes from './Routes'
import './App.css'

const App = () => {
  return (
    <div>
      <Routes />
    </div>
  );
};

export default App;
