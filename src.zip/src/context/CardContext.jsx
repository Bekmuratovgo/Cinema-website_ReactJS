import React from 'react';

const CardContext = () => {
    return (
        <div>
            
        </div>
    );
};

export default CardContext;